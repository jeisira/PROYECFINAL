<?php

  require 'database.php';

 




?>



<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Agregar Proveedores</title>
    <link rel="stylesheet" href="estilo4.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
  </head>
  <body>

    <?php require 'partials/header.php' ?>

    <?php if(!empty($message)): ?>
      <p> <?= $message ?></p>
    <?php endif; ?>

    <h1>Agregar proveedores </h1>
    <span> <a href="index.php">Menu proncipal</a></span>





    <form action="proveedores.php" method="POST">
     
      <input name="Nombre" type="text" placeholder="Nombre del proveedor">
       <input name="Apellido_p" type="text" placeholder="Apellido paterno">
        <input name="Apellido_M" type="text" placeholder="Apellido materno">
         <input name="Codigo" type="text" placeholder="Código">
          <input name="Telefono" type="text" placeholder="Telefono">
      
      <input type="submit" value="Agregar">
    </form>

  </body>
</html>