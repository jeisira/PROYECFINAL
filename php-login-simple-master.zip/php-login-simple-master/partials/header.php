<header>
  <a href="logout.php">Iniciado</a>
</header>
