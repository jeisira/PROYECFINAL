<?php
  session_start();

  require 'database.php';

  
  
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title> almacen </title>
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
  </head>
  <body>
    <?php require 'partials/header.php' ?>

    <?php if(!empty($user)): ?>
      <br> Correo. <?= $user['email']; ?>
      <br>Usuario encontrado
      <a href="logout.php">
        Regresar
      </a>
      <br>
      <a href="inicio/index.php">
        Comenzar  la interfaz
      </a>
    <?php else: ?>
      
<form action="signup.php" >
<input type="submit" value="Agregar producto">
</form>
    
       
       <form action="login.php" >
<input type="submit" value="Modificar producto">
</form>

<form action="eliminar.php" >
<input type="submit" value="Eliminar producto">
</form>
        
         
<form action="proveedores.php" >
<input type="submit" value="Agregar Proveedores">
</form>

<form action="clientes.php" >
<input type="submit" value="Cliente">
</form>

      
    <?php endif; ?>
  </body>
</html>
