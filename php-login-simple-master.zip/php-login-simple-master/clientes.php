<?php

  require 'database.php';

 




?>



<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Agregar clientes</title>
    <link rel="stylesheet" href="estilo4.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
  </head>
  <body>

    <?php require 'partials/header.php' ?>

    <?php if(!empty($message)): ?>
      <p> <?= $message ?></p>
    <?php endif; ?>

    <h1>Agregar clientes </h1>
    <span> <a href="index.php">Menu proncipal</a></span>




    <form action="clientes.php" method="POST">
     
      <input name="Nombre" type="text" placeholder="Nombre del cliente">
       <input name="Direccion" type="text" placeholder="Direccion del cliente">
          <input name="Telefono" type="text" placeholder="Telefono del cliente">
      <input name="Producto" type="text" placeholder="Producto a comprar">
      <input type="submit" value="Agregar">
    </form>

  </body>
</html>