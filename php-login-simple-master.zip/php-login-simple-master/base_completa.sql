drop database if exists databaseUSU;
create database databaseUSU;
use databaseUSU;


create table users(
ID int not null auto_increment primary key,
Email varchar(60)not null,
Password varchar(60) not null
);
	


CREATE TABLE usu (
  id int NOT NULL  auto_increment primary key,
  nombre varchar(20) NOT NULL,
  apellidos varchar(20) NOT NULL,
  correo varchar(20) NOT NULL,
  contrasena varchar(20) NOT NULL
);


CREATE TABLE usu_web(
  id INT(11) PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(255) NOT NULL,
  Email TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

DESCRIBE usu;


