<?php

  require 'database.php';

 




?>



<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Elimar producto</title>
    <link rel="stylesheet" href="estilo.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
  </head>
  <body>

    <?php require 'partials/header.php' ?>

    <?php if(!empty($message)): ?>
      <p> <?= $message ?></p>
    <?php endif; ?>

    <h1>Eliminar producto en almacen</h1>
   <span> <a href="index.php">Menu proncipal</a></span>

    <form action="signup.php" method="POST">
     <form action="login.php" method="POST">
      <input name="matricula" type="text" placeholder="Matricula">
      
      <input type="submit" value="Agregar">
    </form>

  </body>
</html>
