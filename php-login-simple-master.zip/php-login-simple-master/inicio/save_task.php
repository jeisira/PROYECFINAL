<?php

include('db.php');

if (isset($_POST['save_task'])) {
  $nombre = $_POST['nombre'];
  $Email = $_POST['Email'];



if(!empty($nombre) && !empty($Email)){
 $query = "INSERT INTO usu_web(nombre, Email) VALUES ('$nombre', '$Email')";
  $result = mysqli_query($conn, $query);
  if(!$result) {
    die("Ocurrio un Error.");
  }

  $_SESSION['message'] = 'Usuario Registrado Con Exito';
  $_SESSION['message_type'] = 'success';
  header('Location: index.php');

          }else{

            $_SESSION['message'] = 'Usuario no Registrado';
            $_SESSION['message_type'] = 'success';
            header('Location: index.php');
          }




 

}

?>
